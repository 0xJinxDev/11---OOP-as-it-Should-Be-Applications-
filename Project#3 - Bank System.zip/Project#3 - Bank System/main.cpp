#include <iostream>
#include "clsLoginScreen.h"
//#include "clsMainScreen.h"



int main() {

	//clsLoginScreen::ShowLoginScreen();
	//clsMainScreen::ShowMainMenu();
	return 0;
}